﻿namespace PharmaGo.WebApi.Models.In
{
    public class PurchaseAuthorizationModel
    {
        public int pharmacyId { get; set; }
        public string drugCode { get; set; }

    }
}
