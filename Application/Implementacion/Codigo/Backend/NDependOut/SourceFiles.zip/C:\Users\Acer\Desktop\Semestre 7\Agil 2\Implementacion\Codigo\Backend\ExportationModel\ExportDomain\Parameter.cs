﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExportationModel.ExportDomain
{
    public class Parameter
    {
        public string InputName { get; set; }
        public string InputValue { get; set; }
    }
}
